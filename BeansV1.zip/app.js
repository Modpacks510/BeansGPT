// Ensure DOM is ready
document.addEventListener("DOMContentLoaded", () => {
  const messagesDiv = document.getElementById("messages");
  const inputEl = document.getElementById("userInput");
  const sendBtn = document.getElementById("sendBtn");
  const toggleBtn = document.getElementById("toggleMode");

  // Dark mode toggle on body
  toggleBtn.addEventListener("click", () => {
    document.body.classList.toggle("dark-mode");
    // Optional: persist preference
    const isDark = document.body.classList.contains("dark-mode");
    localStorage.setItem("beansgpt-dark", isDark ? "1" : "0");
  });

  // Restore preference
  if (localStorage.getItem("beansgpt-dark") === "1") {
    document.body.classList.add("dark-mode");
  }

  // Send message
  sendBtn.addEventListener("click", sendMessage);
  inputEl.addEventListener("keydown", (e) => {
    if (e.key === "Enter") sendMessage();
  });

  async function sendMessage() {
    const input = inputEl.value.trim();
    if (!input) return;

    // Add user bubble
    const userMsg = document.createElement("p");
    userMsg.classList.add("user");
    userMsg.innerHTML = "<b>You:</b> " + input;
    messagesDiv.appendChild(userMsg);
    inputEl.value = "";

    // Optional: typing indicator
    const typing = document.createElement("p");
    typing.classList.add("ai");
    typing.innerHTML = "<i>BeansGPT is typing…</i>";
    messagesDiv.appendChild(typing);
    messagesDiv.scrollTop = messagesDiv.scrollHeight;

    try {
      const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer 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"
        },
        body: JSON.stringify({
          model: "gpt-4o-mini",
          messages: [{ role: "user", content: input }]
        })
      });

      const data = await response.json();
      const reply = data?.choices?.[0]?.message?.content || "Sorry, I couldn't generate a response.";

      // Replace typing indicator with real reply
      typing.remove();
      const aiMsg = document.createElement("p");
      aiMsg.classList.add("ai");
      aiMsg.innerHTML = "<b>BeansGPT:</b> " + reply;
      messagesDiv.appendChild(aiMsg);
      messagesDiv.scrollTop = messagesDiv.scrollHeight;
    } catch (err) {
      typing.remove();
      const errMsg = document.createElement("p");
      errMsg.classList.add("ai");
      errMsg.innerHTML = "<b>BeansGPT:</b> There was an error responding.";
      messagesDiv.appendChild(errMsg);
    }
  }
});
